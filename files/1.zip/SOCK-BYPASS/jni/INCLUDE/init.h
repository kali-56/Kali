#ifndef XT_ESP_INIT_H
#define XT_ESP_INIT_H

int isName=1;
int isHealth=1;
int isVehicle=1;
int isSkelton=0;
int isItem=1;

bool isLessRecoil = false;
    bool isZeroRecoil = false;
    bool isInstantHit = false;
    bool isFastShootInterval = false;
    bool isSmallCrosshair = false;
    bool isHitX = false;
    bool isNoShake = false;
    bool isWideView = false;
    bool isAimbot = false;
    bool isAimlock = false;
	bool widebool = false;
    bool isFastSwitchWeapon = false;

bool isPremium = false;
float healthbuff[2],health;

#endif //XT_ESP_INIT_H
