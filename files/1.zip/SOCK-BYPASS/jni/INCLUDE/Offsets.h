#ifndef XT_OFFSETS_H
#define XT_OFFSETS_H

namespace OffsetsAll64 {
	uintptr_t Gworld = 0;
	uintptr_t Gname = 0;
	uintptr_t GnamePtr = 0;
	uintptr_t ViewWorld = 0;
	uintptr_t NetDriver = 0;
	uintptr_t ServerConnection = 0;
	uintptr_t PlayerController = 0;
    uintptr_t STExtraBaseCharacter = 0;
	uintptr_t Mesh = 0;
	uintptr_t FixAttachInfoList = 0;
	uintptr_t MinLOD = 0;
	uintptr_t Children = 0;
	uintptr_t DrawShootLineTime = 0;
	uintptr_t UploadInterval = 0;
	uintptr_t CurBulletNumInClip = 0;
	uintptr_t CurMaxBulletNumInOneClip = 0;
	uintptr_t bDead = 0;
	uintptr_t Health = 0;
	uintptr_t TeamID = 0;
	uintptr_t Role = 0;
	uintptr_t bIsAI = 0; 
	uintptr_t PlayerName = 0;
	uintptr_t bIsWeaponFiring = 0;
    uintptr_t bIsGunADS = 0;
    uintptr_t STPlayerController = 0;
    uintptr_t PlayerCameraManager = 0;
    uintptr_t CameraCache = 0;
    uintptr_t MinimalViewInfo = 0;
    uintptr_t MovementCharacter = 0;
	uintptr_t CurrentVehicle = 0;
    uintptr_t ReplicatedMovement = 0;
    uintptr_t Velocity = 0;
	uintptr_t RootComponent = 0;
	uintptr_t ParachuteEquipItems = 0;
	uintptr_t ThirdPersonCameraComponent = 0; 
    uintptr_t FieldOfView = 0;
    uintptr_t WeaponManagerComponent = 0; 
    uintptr_t CurrWeapon = 0;
    uintptr_t ShootWeaponEntityComp = 0;
    uintptr_t BulletFireSpeed = 0;
    uintptr_t ShootInterval = 0;
    uintptr_t AccessoriesVRecoilFactor = 0;
    uintptr_t AccessoriesHRecoilFactor = 0;
    uintptr_t AccessoriesRecoveryFactor = 0;
    uintptr_t GameDeviationFactor = 0;
    uintptr_t RecoilKickADS = 0;
    uintptr_t ExtraHitPerformScale = 0;
    uintptr_t AnimationKick = 0;
    uintptr_t SRecoilInfo = 0;
    uintptr_t AutoAimingConfig = 0;
    uintptr_t SwitchWeaponSpeedScale = 0; 
    uintptr_t VehicleCommon = 0;
    uintptr_t VHealth = 0;
    uintptr_t VHealthMax = 0;
    uintptr_t VFuel = 0;
    uintptr_t VFuelMax = 0;
	uintptr_t PlayerUID = 0; 
    uintptr_t Nation = 0; 
	uintptr_t SlotWeapon = 0;
	uintptr_t ViewPitchMin =0;
    uintptr_t ViewPitchMax = 0;
    uintptr_t ViewYawMin = 0;
    uintptr_t ViewYawMax = 0;
	
    	
	
void GameType64(int a){
    	
if(a == 1){
 //global 64
     Gworld = 0xd40d940;
	 Gname = 0xcca7020;
	 GnamePtr = 0x110;
	 
	 NetDriver = 0x38;
	//NetDriver* NetDriver;//[Offset: 
	
	 ServerConnection = 0x78;
	//NetConnection* ServerConnection;//[Offset:
	
	 PlayerController = 0x30;
	//PlayerController* PlayerController;//[Offset:
	
     STExtraBaseCharacter = 0x2670; ///
    //STExtraBaseCharacter* STExtraBaseCharacter;//[Offset:
    
	 Mesh = 0x498;
    //Class: Character.Pawn.Actor.Object
	//SkeletalMeshComponent* Mesh;//[Offset:
	
	 FixAttachInfoList = 0x1b0;
	//FixAttachInfoList
	
	 MinLOD = 0x878; ///
	//int MinLOD;//[Offset:
	
	 Children = 0x1a0;
	//Actor*[] Children;//[Offset:
	
	 DrawShootLineTime = 0x13c;
	//DrawShootLineTime
	
	 UploadInterval = 0x178; ///
    //float UploadInterval;//[Offset:
	
	 CurBulletNumInClip = 0xee0; ///
	//int CurBulletNumInClip;//[Offset: ///

	 bDead = 0xddc; ///
	//bool bDead;//(ByteOffset: 0, ByteMask: 1, FieldMask: 1)[Offset:
	
	 Health = 0xdc0; ///
	 //Class: STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
	//float Health;//[Offset:
	
	 TeamID = 0x938;
	//Class: UAECharacter.Character.Pawn.Actor.Object
	//int TeamID;//[Offset:
	
	 Role = 0x150;
	//byte Role;//[Offset:

	 bIsAI = 0x9e9; ///
	 //bool bEnsure;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 
	//bool bIsAI;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
	
	 PlayerName = 0x8f0; ///
	 //Class: UAECharacter.Character.Pawn.Actor.Object
	//FString PlayerName;//[Offset:

	 bIsWeaponFiring = 0x1640; ///
	//bool bIsWeaponFiring;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
	
     bIsGunADS = 0x1059; ///
    //bool bIsGunADS;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
    
     STPlayerController = 0x3fc0; ///
    //STExtraPlayerController* STPlayerController;//[Offset:
    
     PlayerCameraManager = 0x4d0;
    //PlayerCameraManager* PlayerCameraManager;//[Offset:
    
     CameraCache = 0x4b0;
    //CameraCacheEntry CameraCache;//[Offset:
    
     MinimalViewInfo = 0x10;
    //MinimalViewInfo POV;//[Offset:
    
     MovementCharacter = 0x4a0;
	 //Class: Character.Pawn.Actor.Object
    //CharacterMovementComponent* CharacterMovement;//[Offset:
    
	 CurrentVehicle = 0xe08; ///
	 //Class: STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
    //STExtraVehicleBase* CurrentVehicle;//[Offset:
    
     ReplicatedMovement = 0xb0;
    //RepMovement ReplicatedMovement;//[Offset:
    
     Velocity = 0x12c; ///
	 //Class: MovementComponent.ActorComponent.Object
    //Vector Velocity;//[Offset: 
	PlayerUID = 0x918; //FString PlayerUID;
    Nation = 0x900; //FString Nation;
	 RootComponent = 0x1b0;
	//SceneComponent* RootComponent;//[Offset:
	
	// ParachuteEquipItems = 0x1b8; ///
	 ParachuteEquipItems = 0x1c0;///
    //int[] ParachuteEquipItems;//[Offset:
    
	 CurrWeapon = 0x500; ///
    //STExtraWeapon* CurrentWeaponReplicated;//[Offset: 
	
	 ShootWeaponEntityComp = 0x1048; ///
	//ShootWeaponEntity* ShootWeaponEntityComp;//[Offset:

     WeaponManagerComponent = 0x2328; ///
	//CharacterWeaponManagerComponent* WeaponManagerComponent;//[Offset:

	 AccessoriesVRecoilFactor = 0xb18;///
	 AccessoriesHRecoilFactor = 0xb1c;///
	 AccessoriesRecoveryFactor = 0xb20;///
	 //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
	//float AccessoriesVRecoilFactor;//[Offset:
	//float AccessoriesHRecoilFactor;//[Offset:
	//float AccessoriesRecoveryFactor;//[Offset:
    VehicleCommon = 0xa28;
	VHealth = 0x2c4; //float HP;//[Offset:
    VHealthMax = 0x2c0;//float HPMax;//[Offset:
    VFuel = 0x33c; //float Fuel;//[Offset:
    VFuelMax = 0x334; //float FuelMax;//[Offset:
     GameDeviationFactor = 0xb90;
	 //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
    //float GameDeviationFactor;//[Offset: 
	CurMaxBulletNumInOneClip = 0xf00;
     AutoAimingConfig = 0x990; ///
	 //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
	// AutoAimingConfig AutoAimingConfig;//[Offset:
    
	 ThirdPersonCameraComponent = 0x1ad0; ///
	//CameraComponent* ThirdPersonCameraComponent;//[Offset:
	
	 FieldOfView = 0x33c; ///
	 //Class: CameraComponent.SceneComponent.ActorComponent.Object
	//float FieldOfView;//[Offset:
	
	 BulletFireSpeed = 0x4f8; ///
	 
	 ShootInterval = 0x530; ///
	 
     RecoilKickADS = 0xc48;///
    
     ExtraHitPerformScale = 0xc4c; ///
    
     AnimationKick = 0xc64; ///
    
     SwitchWeaponSpeedScale = 0x2938; ///
	//  Class: STExtraBaseCharacter.STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
	//float SwitchWeaponSpeedScale 
	
	SlotWeapon = 0x270;
	
	
	ViewPitchMin =0x1cdc;
    ViewPitchMax = 0x1ce0;
    ViewYawMin = 0x1ce4;
    ViewYawMax = 0x1ce8;
	
} else if(a == 2) {
	 //vng 64
     Gworld = 0xd40d940;
	 Gname = 0xcca7020;
	 GnamePtr = 0x110;
	 
	 NetDriver = 0x38;
	//NetDriver* NetDriver;//[Offset: 
	
	 ServerConnection = 0x78;
	//NetConnection* ServerConnection;//[Offset:
	
	 PlayerController = 0x30;
	//PlayerController* PlayerController;//[Offset:
	
     STExtraBaseCharacter = 0x2670; ///
    //STExtraBaseCharacter* STExtraBaseCharacter;//[Offset:
    
	 Mesh = 0x498;
    //Class: Character.Pawn.Actor.Object
	//SkeletalMeshComponent* Mesh;//[Offset:
	
	 FixAttachInfoList = 0x1b0;
	//FixAttachInfoList
	
	 MinLOD = 0x878; ///
	//int MinLOD;//[Offset:
	
	 Children = 0x1a0;
	//Actor*[] Children;//[Offset:
	
	 DrawShootLineTime = 0x13c;
	//DrawShootLineTime
	
	 UploadInterval = 0x178; ///
    //float UploadInterval;//[Offset:
	
	 CurBulletNumInClip = 0xee0; ///
	//int CurBulletNumInClip;//[Offset: ///

	 bDead = 0xddc; ///
	//bool bDead;//(ByteOffset: 0, ByteMask: 1, FieldMask: 1)[Offset:
	
	 Health = 0xdc0; ///
	 //Class: STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
	//float Health;//[Offset:
	
	 TeamID = 0x938;
	//Class: UAECharacter.Character.Pawn.Actor.Object
	//int TeamID;//[Offset:
	
	 Role = 0x150;
	//byte Role;//[Offset:

	 bIsAI = 0x9e9; ///
	 //bool bEnsure;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 
	//bool bIsAI;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
	
	 PlayerName = 0x8f0; ///
	 //Class: UAECharacter.Character.Pawn.Actor.Object
	//FString PlayerName;//[Offset:

	 bIsWeaponFiring = 0x1640; ///
	//bool bIsWeaponFiring;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
	
     bIsGunADS = 0x1059; ///
    //bool bIsGunADS;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
    
     STPlayerController = 0x3fc0; ///
    //STExtraPlayerController* STPlayerController;//[Offset:
    
     PlayerCameraManager = 0x4d0;
    //PlayerCameraManager* PlayerCameraManager;//[Offset:
    
     CameraCache = 0x4b0;
    //CameraCacheEntry CameraCache;//[Offset:
    
     MinimalViewInfo = 0x10;
    //MinimalViewInfo POV;//[Offset:
    
     MovementCharacter = 0x4a0;
	 //Class: Character.Pawn.Actor.Object
    //CharacterMovementComponent* CharacterMovement;//[Offset:
    
	 CurrentVehicle = 0xe08; ///
	 //Class: STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
    //STExtraVehicleBase* CurrentVehicle;//[Offset:
    
     ReplicatedMovement = 0xb0;
    //RepMovement ReplicatedMovement;//[Offset:
    
     Velocity = 0x12c; ///
	 //Class: MovementComponent.ActorComponent.Object
    //Vector Velocity;//[Offset: 
	PlayerUID = 0x918; //FString PlayerUID;
    Nation = 0x900; //FString Nation;
	 RootComponent = 0x1b0;
	//SceneComponent* RootComponent;//[Offset:
	
	// ParachuteEquipItems = 0x1b8; ///
	 ParachuteEquipItems = 0x1c0;///
    //int[] ParachuteEquipItems;//[Offset:
    
	 CurrWeapon = 0x500; ///
    //STExtraWeapon* CurrentWeaponReplicated;//[Offset: 
	
	 ShootWeaponEntityComp = 0xff8; ///
	//ShootWeaponEntity* ShootWeaponEntityComp;//[Offset:

     WeaponManagerComponent = 0x2328; ///
	//CharacterWeaponManagerComponent* WeaponManagerComponent;//[Offset:

	 AccessoriesVRecoilFactor = 0xb18;///
	 AccessoriesHRecoilFactor = 0xb1c;///
	 AccessoriesRecoveryFactor = 0xb20;///
	 //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
	//float AccessoriesVRecoilFactor;//[Offset:
	//float AccessoriesHRecoilFactor;//[Offset:
	//float AccessoriesRecoveryFactor;//[Offset:
    VehicleCommon = 0xa28;
	VHealth = 0x2c4; //float HP;//[Offset:
    VHealthMax = 0x2c0;//float HPMax;//[Offset:
    VFuel = 0x33c; //float Fuel;//[Offset:
    VFuelMax = 0x334; //float FuelMax;//[Offset:
     GameDeviationFactor = 0xb90;
	 //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
    //float GameDeviationFactor;//[Offset: 
	CurMaxBulletNumInOneClip = 0xf00;
     AutoAimingConfig = 0x990; ///
	 //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
	// AutoAimingConfig AutoAimingConfig;//[Offset:
    
	 ThirdPersonCameraComponent = 0x1a90; ///
	//CameraComponent* ThirdPersonCameraComponent;//[Offset:
	
	 FieldOfView = 0x33c; ///
	 //Class: CameraComponent.SceneComponent.ActorComponent.Object
	//float FieldOfView;//[Offset:
	
	 BulletFireSpeed = 0x4f8; ///
	 
	 ShootInterval = 0x530; ///
	 
     RecoilKickADS = 0xc48;///
    
     ExtraHitPerformScale = 0xc4c; ///
    
     AnimationKick = 0xc64; ///
    
     SwitchWeaponSpeedScale = 0x2938; ///
	//  Class: STExtraBaseCharacter.STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
	//float SwitchWeaponSpeedScale 
	
	SlotWeapon = 0x270;
	
	
	ViewPitchMin =0x1cdc;
    ViewPitchMax = 0x1ce0;
    ViewYawMin = 0x1ce4;
    ViewYawMax = 0x1ce8;
   
} else if (a == 3) {
 //bgmi 64
     Gworld = 0xceb78a0;
	 Gname = 0xc7d2e70;
	 GnamePtr = 0x110;
	 
	 NetDriver = 0x38;
	//NetDriver* NetDriver;//[Offset: 
	
	 ServerConnection = 0x78;
	//NetConnection* ServerConnection;//[Offset:
	
	 PlayerController = 0x30;
	//PlayerController* PlayerController;//[Offset:
	
     STExtraBaseCharacter = 0x2640; ///
    //STExtraBaseCharacter* STExtraBaseCharacter;//[Offset:
    
	 Mesh = 0x498;
    //Class: Character.Pawn.Actor.Object
	//SkeletalMeshComponent* Mesh;//[Offset:
	
	 FixAttachInfoList = 0x1b0;
	//FixAttachInfoList
	
	 MinLOD = 0x878; ///
	//int MinLOD;//[Offset:
	
	 Children = 0x1a0;
	//Actor*[] Children;//[Offset:
	
	 DrawShootLineTime = 0x13c;
	//DrawShootLineTime
	
	 UploadInterval = 0x178; ///
    //float UploadInterval;//[Offset:
	
	 CurBulletNumInClip = 0xee0; ///
	//int CurBulletNumInClip;//[Offset: ///

	 bDead = 0xddc; ///
	//bool bDead;//(ByteOffset: 0, ByteMask: 1, FieldMask: 1)[Offset:
	
	 Health = 0xdc0; ///
	 //Class: STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
	//float Health;//[Offset:
	
	 TeamID = 0x938;
	//Class: UAECharacter.Character.Pawn.Actor.Object
	//int TeamID;//[Offset:
	
	 Role = 0x150;
	//byte Role;//[Offset:

	 bIsAI = 0x9e9; ///
	 //bool bEnsure;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 
	//bool bIsAI;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
	
	 PlayerName = 0x8f0; ///
	 //Class: UAECharacter.Character.Pawn.Actor.Object
	//FString PlayerName;//[Offset:

	 bIsWeaponFiring = 0x1640; ///
	//bool bIsWeaponFiring;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
	
     bIsGunADS = 0x1059; ///
    //bool bIsGunADS;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
    
     STPlayerController = 0x3fc0; ///
    //STExtraPlayerController* STPlayerController;//[Offset:
    
     PlayerCameraManager = 0x4d0;
    //PlayerCameraManager* PlayerCameraManager;//[Offset:
    
     CameraCache = 0x4b0;
    //CameraCacheEntry CameraCache;//[Offset:
    
     MinimalViewInfo = 0x10;
    //MinimalViewInfo POV;//[Offset:
    
     MovementCharacter = 0x4a0;
	 //Class: Character.Pawn.Actor.Object
    //CharacterMovementComponent* CharacterMovement;//[Offset:
    
	 CurrentVehicle = 0xe08; ///
	 //Class: STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
    //STExtraVehicleBase* CurrentVehicle;//[Offset:
    
     ReplicatedMovement = 0xb0;
    //RepMovement ReplicatedMovement;//[Offset:
    
     Velocity = 0x12c; ///
	 //Class: MovementComponent.ActorComponent.Object
    //Vector Velocity;//[Offset: 
	PlayerUID = 0x918; //FString PlayerUID;
    Nation = 0x900; //FString Nation;
	 RootComponent = 0x1b0;
	//SceneComponent* RootComponent;//[Offset:
	
	// ParachuteEquipItems = 0x1b8; ///
	 ParachuteEquipItems = 0x1c0;///
    //int[] ParachuteEquipItems;//[Offset:
    
	 CurrWeapon = 0x500; ///
    //STExtraWeapon* CurrentWeaponReplicated;//[Offset: 
	
	 ShootWeaponEntityComp = 0xff8; ///
	//ShootWeaponEntity* ShootWeaponEntityComp;//[Offset:

     WeaponManagerComponent = 0x2328; ///
	//CharacterWeaponManagerComponent* WeaponManagerComponent;//[Offset:

	 AccessoriesVRecoilFactor = 0xb18;///
	 AccessoriesHRecoilFactor = 0xb1c;///
	 AccessoriesRecoveryFactor = 0xb20;///
	 //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
	//float AccessoriesVRecoilFactor;//[Offset:
	//float AccessoriesHRecoilFactor;//[Offset:
	//float AccessoriesRecoveryFactor;//[Offset:
    VehicleCommon = 0xa28;
	VHealth = 0x2c4; //float HP;//[Offset:
    VHealthMax = 0x2c0;//float HPMax;//[Offset:
    VFuel = 0x33c; //float Fuel;//[Offset:
    VFuelMax = 0x334; //float FuelMax;//[Offset:
     GameDeviationFactor = 0xb90;
	 //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
    //float GameDeviationFactor;//[Offset: 
	CurMaxBulletNumInOneClip = 0xf00;
     AutoAimingConfig = 0x990; ///
	 //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
	// AutoAimingConfig AutoAimingConfig;//[Offset:
    
	 ThirdPersonCameraComponent = 0x1a90; ///
	//CameraComponent* ThirdPersonCameraComponent;//[Offset:
	
	 FieldOfView = 0x33c; ///
	 //Class: CameraComponent.SceneComponent.ActorComponent.Object
	//float FieldOfView;//[Offset:
	
	 BulletFireSpeed = 0x4f8; ///
	 
	 ShootInterval = 0x530; ///
	 
     RecoilKickADS = 0xc48;///
    
     ExtraHitPerformScale = 0xc4c; ///
    
     AnimationKick = 0xc64; ///
    
     SwitchWeaponSpeedScale = 0x2938; ///
	//  Class: STExtraBaseCharacter.STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
	//float SwitchWeaponSpeedScale 
	
	SlotWeapon = 0x270;
	
	
	ViewPitchMin =0x1cdc;
    ViewPitchMax = 0x1ce0;
    ViewYawMin = 0x1ce4;
    ViewYawMax = 0x1ce8;
	
    }
}
}


namespace OffsetsAll32 {
	uintptr_t Gworld = 0;
	uintptr_t Gname = 0;
	uintptr_t ViewWorld = 0;
	uintptr_t NetDriver = 0;
	uintptr_t ServerConnection = 0;
	uintptr_t PlayerController = 0;
    uintptr_t STExtraBaseCharacter = 0;
	uintptr_t Mesh = 0;
	uintptr_t FixAttachInfoList = 0;
	uintptr_t MinLOD = 0;
	uintptr_t Children = 0;
	uintptr_t DrawShootLineTime = 0;
	uintptr_t UploadInterval = 0;
	uintptr_t CurBulletNumInClip = 0;
	uintptr_t CurMaxBulletNumInOneClip = 0;
	uintptr_t bDead = 0;
	uintptr_t Health = 0;
	uintptr_t TeamID = 0;
	uintptr_t Role = 0;
	uintptr_t bIsAI = 0; 
	uintptr_t PlayerName = 0;
	uintptr_t bIsWeaponFiring = 0;
    uintptr_t bIsGunADS = 0;
    uintptr_t STPlayerController = 0;
    uintptr_t PlayerCameraManager = 0;
    uintptr_t CameraCache = 0;
    uintptr_t MinimalViewInfo = 0;
    uintptr_t MovementCharacter = 0;
	uintptr_t CurrentVehicle = 0;
    uintptr_t ReplicatedMovement = 0;
    uintptr_t Velocity = 0;
	uintptr_t RootComponent = 0;
	uintptr_t ParachuteEquipItems = 0;
	uintptr_t ThirdPersonCameraComponent = 0; 
    uintptr_t FieldOfView = 0;
    uintptr_t WeaponManagerComponent = 0; 
    uintptr_t CurrWeapon = 0;
    uintptr_t ShootWeaponEntityComp = 0;
    uintptr_t BulletFireSpeed = 0;
    uintptr_t ShootInterval = 0;
    uintptr_t AccessoriesVRecoilFactor = 0;
    uintptr_t AccessoriesHRecoilFactor = 0;
    uintptr_t AccessoriesRecoveryFactor = 0;
    uintptr_t GameDeviationFactor = 0;
	uintptr_t PlayerUID = 0;
    uintptr_t Nation = 0; 
    uintptr_t RecoilKickADS = 0;
    uintptr_t ExtraHitPerformScale = 0;
    uintptr_t AnimationKick = 0;
    uintptr_t SRecoilInfo = 0;
    uintptr_t AutoAimingConfig = 0;
    uintptr_t SwitchWeaponSpeedScale = 0; 
	uintptr_t VehicleCommon = 0;
    uintptr_t VHealth = 0; 
    uintptr_t VHealthMax = 0;
    uintptr_t VFuel = 0; 
    uintptr_t VFuelMax = 0; 
	uintptr_t ViewPitchMin = 0;
    uintptr_t ViewPitchMax = 0;
    uintptr_t ViewYawMin = 0;
    uintptr_t ViewYawMax = 0;
    uintptr_t SlotWeapon = 0;
    
void GameType32(int a){
    	
if(a == 1){
 //gl 32
     Gworld = 0x8fe9514;
	 Gname = 0x8c5f504;
	 
	 NetDriver = 0x24;
	//NetDriver* NetDriver;//[Offset: 
	
	 ServerConnection = 0x60;
	//NetConnection* ServerConnection;//[Offset:
	
	 PlayerController = 0x20;
	//PlayerController* PlayerController;//[Offset:
	
     STExtraBaseCharacter = 0x1d20;
    //STExtraBaseCharacter* STExtraBaseCharacter;//[Offset:
    
	 Mesh = 0x37c;
    //Class: Character.Pawn.Actor.Object
	//SkeletalMeshComponent* Mesh;//[Offset:
	
	 FixAttachInfoList = 0x150;
	//FixAttachInfoList
	
	 MinLOD = 0x6e4; //0x68c
	//int MinLOD;//[Offset:
	
	RootComponent = 0x158;
	//SceneComponent* RootComponent;//[Offset: 0x1b8, Size: 8]
	
	 ParachuteEquipItems = 0x160;
    //int[] ParachuteEquipItems;//[Offset: 0x158, Size: 16]

	 Children = 0x14c;
	//Actor*[] Children;//[Offset:
	
	 DrawShootLineTime = 0xf4;
	//DrawShootLineTime
	
	 UploadInterval = 0x108;
    //float UploadInterval;//[Offset:
	
	 CurBulletNumInClip = 0xb90;
	//int CurBulletNumInClip;//[Offset: 0xd60, Size: 4]

	 bDead = 0xa54;
	//bool bDead;//(ByteOffset: 0, ByteMask: 1, FieldMask: 1)[Offset: 0xcfc, Size: 1]
	
	 Health = 0xa3c;
	//float Health;//[Offset: 0xcb8, Size: 4]
	
	 TeamID = 0x6d4;
	//Class: UAECharacter.Character.Pawn.Actor.Object
	//int TeamID;//[Offset: 0x8c0, Size: 4]
	
	 Role = 0x108;
	//byte Role;//[Offset: 0x140, Size: 1]

	 bIsAI = 0x76d; //bool bEnsure;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 
	//bool bIsAI;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
	
	 PlayerName = 0x6a0;
	//FString PlayerName;//[Offset: 0x878, Size: 16]

	 bIsWeaponFiring = 0x1074;
	//bool bIsWeaponFiring;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 0x14b8, Size: 1]
	
     bIsGunADS = 0xc19;
    //bool bIsGunADS;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 0xf59, Size: 1]
    
     STPlayerController = 0x3194;
    //STExtraPlayerController* STPlayerController;//[Offset:
    
     PlayerCameraManager = 0x3a0;
    //PlayerCameraManager* PlayerCameraManager;//[Offset:
    
     CameraCache = 0x3a0;
    //CameraCacheEntry CameraCache;//[Offset:
    
     MinimalViewInfo = 0x10;
    //MinimalViewInfo POV;//[Offset:
    
     MovementCharacter = 0x380;
    //CharacterMovementComponent* CharacterMovement;//[Offset:
    
	 CurrentVehicle = 0xa74;
    //STExtraVehicleBase* CurrentVehicle;//[Offset:
    
     ReplicatedMovement = 0x80;
    //RepMovement ReplicatedMovement;//[Offset:
    
     Velocity = 0xd0;
    //Vector Velocity;//[Offset: 
	 VehicleCommon = 0x7d0;
	VHealth = 0x200;
    //float HP;//[Offset: 0x2a4, Size: 0x4]
     CurMaxBulletNumInOneClip = 0xba4;
     VHealthMax = 0x1fc;
    //float HPMax;//[Offset: 0x2a0, Size: 0x4]
    
     VFuel = 0x25c;
    //float Fuel;//[Offset: 0x2c8, Size: 0x4]
    
     VFuelMax = 0x258;
	//float FuelMax;//[Offset: 0x2c4, Size: 0x4]
    
	 ThirdPersonCameraComponent = 0x1448; 
	 //CameraComponent* ThirdPersonCameraComponent
	 
     FieldOfView = 0x2cc; //float FieldOfView
    
     WeaponManagerComponent = 0x1ae0; 
	 //CharacterWeaponManagerComponent* WeaponManagerComponent
	 
     CurrWeapon = 0x40c; 
	 //STExtraWeapon* CurrentWeaponReplicated
	 
     ShootWeaponEntityComp = 0xcb8;  
	 //ShootWeaponEntity* ShootWeaponEntityComp
    
    //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
    
     BulletFireSpeed = 0x420;
     ShootInterval = 0x44c;
     PlayerUID = 0x6bc; //FString PlayerUID;
     Nation = 0x6ac; //FString Nation;
     AccessoriesVRecoilFactor = 0x91c;
     AccessoriesHRecoilFactor = 0x920;
     AccessoriesRecoveryFactor = 0x924;
    
     GameDeviationFactor = 0x984;
    
     RecoilKickADS = 0xa30;
    
     ExtraHitPerformScale = 0xa34;
    
     AnimationKick = 0xa4c;
    
     AutoAimingConfig = 0x7b8;
    
     SwitchWeaponSpeedScale = 0x1f3c; //float SwitchWeaponSpeedScale 
 
	ViewPitchMin = 0x1ac0;
    ViewPitchMax = 0x1ac4;
    ViewYawMin = 0x1ac8;
    ViewYawMax = 0x1acc;
	SlotWeapon = 0X1D0;
	
	
} else if (a == 2) {
  //vng 32
	 Gworld = 0x8fe9514;
	 Gname = 0x8c5f504;
	 
	 NetDriver = 0x24;
	//NetDriver* NetDriver;//[Offset: 
	
	 ServerConnection = 0x60;
	//NetConnection* ServerConnection;//[Offset:
	
	 PlayerController = 0x20;
	//PlayerController* PlayerController;//[Offset:
	
     STExtraBaseCharacter = 0x1d20;
    //STExtraBaseCharacter* STExtraBaseCharacter;//[Offset:
     CurMaxBulletNumInOneClip = 0xba4;
	 Mesh = 0x37c;
    //Class: Character.Pawn.Actor.Object
	//SkeletalMeshComponent* Mesh;//[Offset:
	
	 FixAttachInfoList = 0x150;
	//FixAttachInfoList
	
	 MinLOD = 0x6e4; //0x68c
	//int MinLOD;//[Offset:
	
	RootComponent = 0x158;
	//SceneComponent* RootComponent;//[Offset: 0x1b8, Size: 8]
	
	 ParachuteEquipItems = 0x160;
    //int[] ParachuteEquipItems;//[Offset: 0x158, Size: 16]

	 Children = 0x14c;
	//Actor*[] Children;//[Offset:
	
	 DrawShootLineTime = 0xf4;
	//DrawShootLineTime
	
	 UploadInterval = 0x108;
    //float UploadInterval;//[Offset:
	
	 CurBulletNumInClip = 0xb90;
	//int CurBulletNumInClip;//[Offset: 0xd60, Size: 4]

	 bDead = 0xa54;
	//bool bDead;//(ByteOffset: 0, ByteMask: 1, FieldMask: 1)[Offset: 0xcfc, Size: 1]
	
	 Health = 0xa3c;
	//float Health;//[Offset: 0xcb8, Size: 4]
	
	 TeamID = 0x6d4;
	//Class: UAECharacter.Character.Pawn.Actor.Object
	//int TeamID;//[Offset: 0x8c0, Size: 4]
	
	 Role = 0x108;
	//byte Role;//[Offset: 0x140, Size: 1]

	 bIsAI = 0x76d; //bool bEnsure;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 
	//bool bIsAI;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
	
	 PlayerName = 0x6a0;
	//FString PlayerName;//[Offset: 0x878, Size: 16]

	 bIsWeaponFiring = 0x1074;
	//bool bIsWeaponFiring;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 0x14b8, Size: 1]
	
     bIsGunADS = 0xc19;
    //bool bIsGunADS;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 0xf59, Size: 1]
    PlayerUID = 0x6bc; //FString PlayerUID;
     Nation = 0x6ac; //FString Nation;
     STPlayerController = 0x3194;
    //STExtraPlayerController* STPlayerController;//[Offset:
    
     PlayerCameraManager = 0x3a0;
    //PlayerCameraManager* PlayerCameraManager;//[Offset:
    
     CameraCache = 0x3a0;
    //CameraCacheEntry CameraCache;//[Offset:
    
     MinimalViewInfo = 0x10;
    //MinimalViewInfo POV;//[Offset:
    
     MovementCharacter = 0x380;
    //CharacterMovementComponent* CharacterMovement;//[Offset:
    
	 CurrentVehicle = 0xa74;
    //STExtraVehicleBase* CurrentVehicle;//[Offset:
    
     ReplicatedMovement = 0x80;
    //RepMovement ReplicatedMovement;//[Offset:
    
     Velocity = 0xd0;
    //Vector Velocity;//[Offset: 
    VehicleCommon = 0x7d0;
	 VHealth = 0x200;
    //float HP;//[Offset: 0x2a4, Size: 0x4]
    
     VHealthMax = 0x1fc;
    //float HPMax;//[Offset: 0x2a0, Size: 0x4]
    
     VFuel = 0x25c;
    //float Fuel;//[Offset: 0x2c8, Size: 0x4]
    
     VFuelMax = 0x258;
	//float FuelMax;//[Offset: 0x2c4, Size: 0x4]
	 
    
	 ThirdPersonCameraComponent = 0x1448; 
	 //CameraComponent* ThirdPersonCameraComponent
	 
     FieldOfView = 0x2cc; //float FieldOfView
    
     WeaponManagerComponent = 0x1ae0; 
	 //CharacterWeaponManagerComponent* WeaponManagerComponent
	 
     CurrWeapon = 0x40c; 
	 //STExtraWeapon* CurrentWeaponReplicated
	 
     ShootWeaponEntityComp = 0xcb8;  
	 //ShootWeaponEntity* ShootWeaponEntityComp
    
    //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
    
     BulletFireSpeed = 0x420;
     ShootInterval = 0x44c;
    
     AccessoriesVRecoilFactor = 0x91c;
     AccessoriesHRecoilFactor = 0x920;
     AccessoriesRecoveryFactor = 0x924;
    
     GameDeviationFactor = 0x984;
    
     RecoilKickADS = 0xa30;
    
     ExtraHitPerformScale = 0xa34;
    
     AnimationKick = 0xa4c;
    
     AutoAimingConfig = 0x7b8;
    
     SwitchWeaponSpeedScale = 0x1f3c; //float SwitchWeaponSpeedScale 
 
	 ViewPitchMin = 0x1ac0;
     ViewPitchMax = 0x1ac4;
     ViewYawMin = 0x1ac8;
     ViewYawMax = 0x1acc;
	 SlotWeapon = 0X1D0;
	
 } else {
	 //bgmi 32
	 Gworld = 0x907f6ec;
	 Gname = 0x8b4ee54;
	 
	 NetDriver = 0x24;
	//NetDriver* NetDriver;//[Offset: 
	
	 ServerConnection = 0x60;
	//NetConnection* ServerConnection;//[Offset:
	
	 PlayerController = 0x20;
	//PlayerController* PlayerController;//[Offset:
	
     STExtraBaseCharacter = 0x1ce0;
    //STExtraBaseCharacter* STExtraBaseCharacter;//[Offset:
     CurMaxBulletNumInOneClip = 0xba4;
	 Mesh = 0x378;
    //Class: Character.Pawn.Actor.Object
	//SkeletalMeshComponent* Mesh;//[Offset:
	
	 FixAttachInfoList = 0x150;
	//FixAttachInfoList
	
	 MinLOD = 0x6e4; //0x68c
	//int MinLOD;//[Offset:
	
	 Children = 0x14c;
	//Actor*[] Children;//[Offset:
	
	 DrawShootLineTime = 0xf4;
	//DrawShootLineTime
	
	 UploadInterval = 0x108;
    //float UploadInterval;//[Offset:
	PlayerUID = 0x6bc; //FString PlayerUID;
     Nation = 0x6ac; //FString Nation;
	 CurBulletNumInClip = 0xbd0;
	//int CurBulletNumInClip;//[Offset: 0xd60, Size: 4]

	 bDead = 0xa64;
	//bool bDead;//(ByteOffset: 0, ByteMask: 1, FieldMask: 1)[Offset: 0xcfc, Size: 1]
	
	 Health = 0xa4c;
	//float Health;//[Offset: 0xcb8, Size: 4]
	
	 TeamID = 0x6e4;
	//Class: UAECharacter.Character.Pawn.Actor.Object
	//int TeamID;//[Offset: 0x8c0, Size: 4]
	
	 Role = 0x108;
	//byte Role;//[Offset: 0x140, Size: 1]

	 bIsAI = 0x77d; //bool bEnsure;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 
	//bool bIsAI;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset:
	
	 PlayerName = 0x678;
	//FString PlayerName;//[Offset: 0x878, Size: 16]

	 bIsWeaponFiring = 0x1084;
	//bool bIsWeaponFiring;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 0x14b8, Size: 1]
	
     bIsGunADS = 0xc29;
    //bool bIsGunADS;//(ByteOffset: 0, ByteMask: 1, FieldMask: 255)[Offset: 0xf59, Size: 1]
    
     STPlayerController = 0x3184;
    //STExtraPlayerController* STPlayerController;//[Offset:
    
     PlayerCameraManager = 0x398;
    //PlayerCameraManager* PlayerCameraManager;//[Offset:
    
     CameraCache = 0x3a0;
    //CameraCacheEntry CameraCache;//[Offset:
    
     MinimalViewInfo = 0x10;
    //MinimalViewInfo POV;//[Offset:
    
     MovementCharacter = 0x37c;
    //CharacterMovementComponent* CharacterMovement;//[Offset:
    
	 CurrentVehicle = 0xa84;
    //STExtraVehicleBase* CurrentVehicle;//[Offset:
    
     ReplicatedMovement = 0x80;
    //RepMovement ReplicatedMovement;//[Offset:
     VehicleCommon = 0x7d0;
     Velocity = 0xd0;
    //Vector Velocity;//[Offset: 
	
	 RootComponent = 0x158;
	//SceneComponent* RootComponent;//[Offset: 0x1b8, Size: 8]
	
	 ParachuteEquipItems = 0x160;
    //int[] ParachuteEquipItems;//[Offset: 0x158, Size: 16]
    
	 ThirdPersonCameraComponent = 0x1450; //CameraComponent* ThirdPersonCameraComponent
     FieldOfView = 0x2cc; //float FieldOfView
    
    
     WeaponManagerComponent = 0x1af0; //CharacterWeaponManagerComponent* WeaponManagerComponent
     CurrWeapon = 0x40c; //STExtraWeapon* CurrentWeaponReplicated
     ShootWeaponEntityComp = 0xcf8;  //ShootWeaponEntity* ShootWeaponEntityComp
    
    //Class: ShootWeaponEntity.WeaponEntity.WeaponLogicBaseComponent.ActorComponent.Object
    
     BulletFireSpeed = 0x420;
     ShootInterval = 0x44c;
    
     AccessoriesVRecoilFactor = 0x924;
     AccessoriesHRecoilFactor = 0x928;
     AccessoriesRecoveryFactor = 0x92c;
    
     GameDeviationFactor = 0x98c;
    
     RecoilKickADS = 0xa38;
    
     ExtraHitPerformScale = 0xa3c;
    
     AnimationKick = 0xa54;
    
     
    
     AutoAimingConfig = 0x7c0;
    
     SwitchWeaponSpeedScale = 0x1f4c; //float SwitchWeaponSpeedScale 
    
     
	ViewPitchMin = 0x1ac0;
    ViewPitchMax = 0x1ac4;
    ViewYawMin = 0x1ac8;
    ViewYawMax = 0x1acc;
	SlotWeapon = 0X1D0;
	}
}

}



#endif //XT_OFFSETS_H

