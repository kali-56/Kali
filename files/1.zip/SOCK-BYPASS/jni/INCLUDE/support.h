#ifndef XT_ESP_SUPPORT_H
#define XT_ESP_SUPPORT_H

#include "socket.h"
#define PI 3.141592653589793238
ssize_t process_v(pid_t __pid, const struct iovec *__local_iov, unsigned long __local_iov_count,
				  const struct iovec *__remote_iov, unsigned long __remote_iov_count,
				  unsigned long __flags, bool iswrite)
{
	return syscall((iswrite ? process_vm_writev_syscall : process_vm_readv_syscall), __pid,
				   __local_iov, __local_iov_count, __remote_iov, __remote_iov_count, __flags);
}


bool pvm(void *address, void *buffer, size_t size, bool iswrite)
{
	struct iovec local[1];
	struct iovec remote[1];
	local[0].iov_base = buffer;
	local[0].iov_len = size;
	remote[0].iov_base = address;
	remote[0].iov_len = size;
	if (pid < 0)
	{
		return false;
	}
	ssize_t bytes = process_v(pid, local, 1, remote, 1, 0, iswrite);
	return bytes == size;
}


template<typename T>
T Read(unsigned long address) {
    T data;
    pvm(reinterpret_cast < void *>(address), reinterpret_cast<void *>(&data), sizeof(T), false);
    return data;
}


bool vm_readv(unsigned long address, void *buffer, size_t size)
{
	return pvm(reinterpret_cast < void *>(address), buffer, size, false);
}

bool vm_writev(unsigned long address, void *buffer, size_t size)
{
	return pvm(reinterpret_cast < void *>(address), buffer, size, true);
}
template<typename T>
void Writes(unsigned long address, T data) {
    pvm(reinterpret_cast < void *>(address), reinterpret_cast<void *>(&data), sizeof(T), true);
}

template <typename T>
struct TArray {
    uintptr_t base;
    int32_t count;
    int32_t max;

    std::vector<T> ToVec() const {
        if (!IsValid()) {
            return {};
        }
        std::vector<T> vec{};
        vec.resize(static_cast<size_t>(count));
        iovec l_iov{&vec[0], static_cast<size_t>(count) * sizeof(T)};
        iovec r_iov{reinterpret_cast<void*>(base), static_cast<size_t>(count) * sizeof(T)};
        syscall(process_vm_readv_syscall, pid, &l_iov, 1, &r_iov, 1, 0);
        return vec;
    }

    T operator[](size_t u) const {
        return Read<T>(base + u * sizeof(T));
    }

    bool IsValid() const {
        return base && count > 0 && count <= max && max > 0;
    }
};
//start 64
struct ActorsEncryption64 {
    uint64_t Enc_1, Enc_2;
    uint64_t Enc_3, Enc_4;
};

struct Encryption_Chunk64 {
    uint32_t val_1, val_2, val_3, val_4;
    uint32_t val_5, val_6, val_7, val_8;
};

uint64_t DecryptActorsArray64(uint64_t uLevel, int Actors_Offset, int EncryptedActors_Offset) {
    if (uLevel < 0x10000000)
        return 0;

    if (Read<uint64_t>(uLevel + Actors_Offset) > 0)
        return uLevel + Actors_Offset;

    if (Read<uint64_t>(uLevel + EncryptedActors_Offset) > 0)
        return uLevel + EncryptedActors_Offset;

    auto Encryption = Read<ActorsEncryption64>(uLevel + EncryptedActors_Offset + 0x10);

    if (Encryption.Enc_1 > 0) {
        auto Enc = Read<Encryption_Chunk64>(Encryption.Enc_1 + 0x80);
        return (((Read<uint8_t>(Encryption.Enc_1 + Enc.val_1)
                  | (Read<uint8_t>(Encryption.Enc_1 + Enc.val_2) << 8))
                 | (Read<uint8_t>(Encryption.Enc_1 + Enc.val_3) << 0x10)) & 0xFFFFFF
                | ((uint64_t) Read<uint8_t>(Encryption.Enc_1 + Enc.val_4) << 0x18)
                | ((uint64_t) Read<uint8_t>(Encryption.Enc_1 + Enc.val_5) << 0x20)) &
               0xFFFF00FFFFFFFFFF
               | ((uint64_t) Read<uint8_t>(Encryption.Enc_1 + Enc.val_6) << 0x28)
               | ((uint64_t) Read<uint8_t>(Encryption.Enc_1 + Enc.val_7) << 0x30)
               | ((uint64_t) Read<uint8_t>(Encryption.Enc_1 + Enc.val_8) << 0x38);
    } else if (Encryption.Enc_2 > 0) {
        auto Encrypted_Actors = Read<uint64_t>(Encryption.Enc_2);
        if (Encrypted_Actors > 0) {
            return (uint16_t) (Encrypted_Actors - 0x400) & 0xFF00
                   | (uint8_t) (Encrypted_Actors - 0x04)
                   | (Encrypted_Actors + 0xFC0000) & 0xFF0000
                   | (Encrypted_Actors - 0x4000000) & 0xFF000000
                   | (Encrypted_Actors + 0xFC00000000) & 0xFF00000000
                   | (Encrypted_Actors + 0xFC0000000000) & 0xFF0000000000
                   | (Encrypted_Actors + 0xFC000000000000) & 0xFF000000000000
                   | (Encrypted_Actors - 0x400000000000000) & 0xFF00000000000000;
        }
    } else if (Encryption.Enc_3 > 0) {
        auto Encrypted_Actors = Read<uint64_t>(Encryption.Enc_3);
        if (Encrypted_Actors > 0)
            return (Encrypted_Actors >> 0x38) | (Encrypted_Actors << (64 - 0x38));
    } else if (Encryption.Enc_4 > 0) {
        auto Encrypted_Actors = Read<uint64_t>(Encryption.Enc_4);
        if (Encrypted_Actors > 0)
            return Encrypted_Actors ^ 0xCDCD00;
    }
    return 0;
}
//end 64

//start32
struct ActorsEncryption32 {
	uint32_t Enc_1, Enc_2;
	uint32_t Enc_3, Enc_4;
};
 
struct Encryption_Chunk32 {
	uint32_t val_1, val_2;
	uint32_t val_3, val_4;
};

uint32_t DecryptActorsArray32(uint32_t uLevel, int Actors_Offset, int EncryptedActors_Offset)
{
	if (uLevel < 0x10000000)
		return 0;
 
	if (Read<uint32_t>(uLevel + Actors_Offset) > 0)
		return uLevel + Actors_Offset;
 
	if (Read<uint32_t>(uLevel + EncryptedActors_Offset) > 0)
		return uLevel + EncryptedActors_Offset;
 
	auto Encryption = Read<ActorsEncryption32>(uLevel + EncryptedActors_Offset + 0x0C);
 
	if (Encryption.Enc_1 > 0)
	{
		auto Enc = Read<Encryption_Chunk32>(Encryption.Enc_1 + 0x80);
 
		return (Read<uint8_t>(Encryption.Enc_1 + Enc.val_1)
			| (Read<uint8_t>(Encryption.Enc_1 + Enc.val_2) << 8)
			| (Read<uint8_t>(Encryption.Enc_1 + Enc.val_3) << 0x10)
			| (Read<uint8_t>(Encryption.Enc_1 + Enc.val_4) << 0x18));
	}
	else if (Encryption.Enc_2 > 0)
	{
		auto Encrypted_Actors = Read<uint32_t>(Encryption.Enc_2);
		if (Encrypted_Actors > 0)
		{
			return ((unsigned short)Encrypted_Actors - 0x400) & 0xFF00
				| (unsigned char)(Encrypted_Actors - 0x04)
				| (Encrypted_Actors + 0xFC0000) & 0xFF0000
				| (Encrypted_Actors - 0x4000000) & 0xFF000000;
		}
	}
	else if (Encryption.Enc_3 > 0)
	{
		auto Encrypted_Actors = Read<uint32_t>(Encryption.Enc_3);
		if (Encrypted_Actors > 0)
			return (Encrypted_Actors >> 0x18) | (Encrypted_Actors << (32 - 0x18));
	}
	else if (Encryption.Enc_4 > 0)
	{
		auto Encrypted_Actors = Read<uint32_t>(Encryption.Enc_4);
		if (Encrypted_Actors > 0)
			return Encrypted_Actors ^ 0xCDCD00;
	}
	return 0;
}

//end32


float get_3D_Distance(float Self_x, float Self_y, float Self_z, float Object_x, float Object_y, float Object_z)
{
	float x, y, z;
	x = Self_x - Object_x;
	y = Self_y - Object_y;
	z = Self_z - Object_z;
	return (float)(sqrt(x * x + y * y + z * z));
}

struct D3DMatrix ToMatrixWithScale(struct Vec3 translation,struct Vec3 scale,struct Vec4 rot)
{
	struct D3DMatrix m;

	m._41 = translation.X;
	m._42 = translation.Y;
	m._43 = translation.Z;

	float x2 = rot.X + rot.X;
	float y2 = rot.Y + rot.Y;
	float z2 = rot.Z + rot.Z;

	float xx2 = rot.X * x2;
	float yy2 = rot.Y * y2;
	float zz2 = rot.Z * z2;

	m._11 = (1.0f - (yy2 + zz2)) * scale.X;
	m._22 = (1.0f - (xx2 + zz2)) * scale.Y;
	m._33 = (1.0f - (xx2 + yy2)) * scale.Z;

	float wx2 = rot.W * x2;
	float yz2 = rot.Y * z2;

	m._23 = (yz2 + wx2) * scale.Y;
	m._32 = (yz2 - wx2) * scale.Z;

	float xy2 = rot.X * y2;
	float wz2 = rot.W * z2;

	m._12 = (xy2 + wz2) * scale.X;
	m._21 = (xy2 - wz2) * scale.Y;

	float xz2 = rot.X * z2;
	float wy2 = rot.W * y2;

	m._13 = (xz2 - wy2) * scale.X;
	m._31 = (xz2 + wy2) * scale.Z;

	m._14 = 0.0f;
	m._24 = 0.0f;
	m._34 = 0.0f;
	m._44 = 1.0f;

	return m;
}

struct Vec3 mat2Cord(struct D3DMatrix pM1,struct D3DMatrix pM2)
{
	struct  Vec3 pOut;

	pOut.X = pM1._41 * pM2._11 + pM1._42 * pM2._21 + pM1._43 * pM2._31 + pM1._44 * pM2._41;
	pOut.Y = pM1._41 * pM2._12 + pM1._42 * pM2._22 + pM1._43 * pM2._32 + pM1._44 * pM2._42;
	pOut.Z = pM1._41 * pM2._13 + pM1._42 * pM2._23 + pM1._43 * pM2._33 + pM1._44 * pM2._43;

	return pOut;
}

uintptr_t getBase() {
    FILE *fp;
    uintptr_t addr = 0;
    char filename[32], buffer[1024];
    snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
    fp = fopen(filename, "rt");
    if (fp != nullptr) {
        while (fgets(buffer, sizeof(buffer), fp)) {
            if (strstr(buffer, "libUE4.so")) {
#if defined(__LP64__)
                sscanf(buffer, "%lx-%*s", &addr);
#else
                sscanf(buffer, "%x-%*s", &addr);
#endif
                break;
            }
        }
        fclose(fp);
    }
    return addr;
}

pid_t getPid(char * name)
{
	char text[69];
	pid_t pid = 0;
	sprintf(text,"pidof %s",name);
	FILE *chkRun = popen(text, "r");
	if (chkRun)
	{
		char output[10];
		fgets(output ,10,chkRun);
		pclose(chkRun);
		pid= atoi(output);
	}
	if (pid < 10)
	{
		DIR* dir = NULL;
		struct dirent* ptr = NULL;
		FILE* fp = NULL;
		char filepath[256];
		char filetext[128];
		dir = opendir("/proc");
		if (NULL != dir)
		{
			while ((ptr = readdir(dir)) != NULL)
			{
				if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
					continue;
				if (ptr->d_type != DT_DIR)
					continue;
				sprintf(filepath, "/proc/%s/cmdline", ptr->d_name);
				fp = fopen(filepath, "r");
				if (NULL != fp)
				{
					fgets(filetext, sizeof(filetext), fp);
					if (strcmp(filetext, name) == 0)
					{
						fclose(fp);
						break;
					}
					fclose(fp);
				}
			}
		}
		if (readdir(dir) == NULL)
		{
			closedir(dir);
			return 0;
		}
		closedir(dir);
		pid= atoi(ptr->d_name);
	}
	return pid;
}

float getF(uintptr_t address)
{
	float buff;
	vm_readv(address, &buff, 4);
	return buff;
}

uintptr_t getA(uintptr_t address)
{
	uintptr_t buff;
    vm_readv(address, &buff, SIZE);
    return buff;
}

int getI(uintptr_t address)
{
	int buff;
	vm_readv(address, &buff, 4);
	return buff;
}

Vec3 Multiply_VectorFloat(const Vec3& Vec, float Scale)
{
    Vec3 multiply = {Vec.X * Scale, Vec.Y * Scale, Vec.Z * Scale};
    return multiply;
}

Vec3 Add_VectorVector(struct Vec3 Vect1, struct Vec3 Vect2)
{
    Vec3 add;
    add.X = Vect1.X + Vect2.X;
    add.Y = Vect1.Y + Vect2.Y;
    add.Z = Vect1.Z + Vect2.Z;
    return add;
}

Vec3 getVec3(uintptr_t addr) {
    Vec3 vec;
    vm_readv(addr, &vec, sizeof(vec));
    return vec;
}


int isValidItem(int id)
{
	if (id >= 100000 && id < 999999)
		return 1;
    return 0;
}

int isValid64(uintptr_t addr)
{
    if (addr < 0x1000000000 || addr>0xefffffffff || addr % SIZE != 0)
        return 0;
    return 1;
}

int isValid32(uintptr_t addr)
{
    if (addr < 0x10000000 || addr>0xefffffff || addr % SIZE != 0)
        return 0;
    return 1;
}

float getDistance(struct Vec3 mxyz,struct Vec3 exyz)
{
	return sqrt ((mxyz.X-exyz.X)*(mxyz.X-exyz.X)+(mxyz.Y-exyz.Y)*(mxyz.Y-exyz.Y)+(mxyz.Z-exyz.Z)*(mxyz.Z-exyz.Z))/100;
}

struct Vec3 World2Screen(struct D3DMatrix viewMatrix, struct Vec3 pos)
{
	struct Vec3 screen;
	float screenW = (viewMatrix._14 * pos.X) + (viewMatrix._24 * pos.Y) + (viewMatrix._34 * pos.Z) + viewMatrix._44;

	if (screenW < 0.01f)
		screen.Z = 1;
	else
		screen.Z = 0;

	float screenX = (viewMatrix._11 * pos.X) + (viewMatrix._21 * pos.Y) + (viewMatrix._31 * pos.Z) + viewMatrix._41;
	float screenY = (viewMatrix._12 * pos.X) + (viewMatrix._22 * pos.Y) + (viewMatrix._32 * pos.Z) + viewMatrix._42;
	screen.Y = (height / 2) - (height / 2) * screenY / screenW;
	screen.X = (width / 2) + (width / 2) * screenX / screenW;

	return screen;
}

struct Vec2 World2ScreenMain(struct D3DMatrix viewMatrix, struct Vec3 pos)
{
	struct Vec2 screen;
	float screenW = (viewMatrix._14 * pos.X) + (viewMatrix._24 * pos.Y) + (viewMatrix._34 * pos.Z) + viewMatrix._44;

	float screenX = (viewMatrix._11 * pos.X) + (viewMatrix._21 * pos.Y) + (viewMatrix._31 * pos.Z) + viewMatrix._41;
	float screenY = (viewMatrix._12 * pos.X) + (viewMatrix._22 * pos.Y) + (viewMatrix._32 * pos.Z) + viewMatrix._42;
	screen.Y = (height / 2) - (height / 2) * screenY / screenW;
	screen.X = (width / 2) + (width / 2) * screenX / screenW;

	return screen;
}

struct D3DMatrix getOMatrix(uintptr_t boneAddr)
{
    float oMat[11];
    vm_readv(boneAddr,&oMat,sizeof(oMat));
    rot.X=oMat[0];
	rot.Y=oMat[1];
	rot.Z=oMat[2];
	rot.W=oMat[3];
			
	tran.X=oMat[4];
	tran.Y=oMat[5];
	tran.Z=oMat[6];
			
	scale.X=oMat[8];
	scale.Y=oMat[9];
	scale.Z=oMat[10];
			
	return ToMatrixWithScale(tran,scale,rot);
}

Vec3 CalcMousePos(Vec3 headPos, Vec3 uMyobejctPos) {
    Vec3 AimPos;
    float x = headPos.X - uMyobejctPos.X;
    float y = headPos.Y - uMyobejctPos.Y;
    float z = headPos.Z - uMyobejctPos.Z;
    AimPos.X = atan2(y, x) * 180.f / M_PI;
    AimPos.Y = atan2(z, sqrt(x * x + y * y)) * 180.f / PI;
    return AimPos;
}

char* getText(uintptr_t addr)
{
	static char txt[42];
	memset(txt, 0, 42);
	char buff[41];
	vm_readv(addr + 4+SIZE, &buff, 41);
	int i;
	for (i = 0; i < 41; i++) {
		if (buff[i] == 0)
			break;
		txt[i] = buff[i];
		if (buff[i] == 67 && i > 10)
			break;
	}
	txt[i + 1] = '\0';
	return txt;
}

char *getNameByte(uintptr_t address)
{
	char static lj[64];
	memset(lj, 0, 64);
	unsigned short int nameI[32];
	vm_readv(address, nameI, sizeof(nameI));
	char s[10];
	int i;
	for (i = 0; i < 32; i++)
	{
		if (nameI[i] == 0)
			break;
		sprintf(s, "%d:", nameI[i]);
		strcat(lj, s);
	}
	lj[63] = '\0';

	return lj;
}

void dump(const uintptr_t gaddr, const int gsize, char* name)
{
	char buff[0x100000];
	uintptr_t addr = gaddr;
	int size = gsize;
	FILE* fp = fopen(name, "w");
	while (size > 0) {
		if (size < 0x100000) {
			vm_readv(addr, buff, size);
			for (int i = 0; i < size; i++)
				fwrite(&buff[i], 1, 1, fp);
		} else {
			vm_readv(addr, buff, 0x100000);
			for (int i = 0; i < 0x100000; i++)
				fwrite(&buff[i], 1, 1, fp);
		}
		addr += 0x100000;
		size -= 0x100000;
	}
	fclose(fp);
}

void getGNameRes(uintptr_t gname, uintptr_t pBase, char *name) {
    uintptr_t gname_buff[30];
    vm_readv(gname, &gname_buff, sizeof(gname_buff));
    int ids = Read<int>(pBase + 8 + 2 * SIZE);
    int page = ids / 0x4000;
    int index = ids % 0x4000;
    if (page > 1 || page < 30) {
        if (gname_buff[page] == 0)
            gname_buff[page] = Read<uintptr_t>(gname + page * SIZE);
        strcpy(name, getText(Read<uintptr_t>(gname_buff[page] + index * SIZE)));
    }
}

enum type {
	TYPE_DWORD,
	TYPE_FLOAT
};

void WriteDword(uintptr_t address, int value) {
    pvm(reinterpret_cast<void *>(address), reinterpret_cast<void *>(&value), 4, true);
}

void WriteFloat(uintptr_t address, float value) {
    pvm(reinterpret_cast<void *>(address), reinterpret_cast<void *>(&value), 4, true);
}

void Write(uintptr_t address, const char *value, type TYPE) {
    switch (TYPE) {
        case TYPE_DWORD:
            WriteDword(address, atoi(value));
            break;
        case TYPE_FLOAT:
            WriteFloat(address, atof(value));
            break;
    }
}

bool ProcessRead1(void *address, void *buffer, size_t size, bool write = false) {
    struct iovec local[1];
    struct iovec remote[1];

    local[0].iov_base = (void *)buffer;
    local[0].iov_len = size;
    remote[0].iov_base = (void *)address;
    remote[0].iov_len = size;

    if (pid < 0) {
        return false;
    }

    ssize_t bytes = syscall((write ? process_vm_writev_syscall : process_vm_readv_syscall), pid, local, 1, remote, 1, 0, write);
    return bytes == size;
}


bool PVM_WriteAddr(void *addr, void *buffer, size_t length) {
    return ProcessRead1(addr, buffer, length, true);
}

template<typename T>
void Write2(uintptr_t addr, T value) {
    PVM_WriteAddr((void *) addr, &value, sizeof(T));
}

float GetPitch(float Fov,float compe,float dist) {
    if ((int) Fov == 70) // no scope
    {
        return ((30.0f / 30) * compe) + dist;
    } else if ((int) Fov == 55) // redot
    {
		return ((33.75f / 30) * compe) + dist;
		
	} else if ((int) Fov == 44) //x2
	{
        return ((45.0f / 30) * compe) + dist;
		
	} else if ((int) Fov == 26) //x3
	{
		return ((60.0f / 30) * compe) + dist;
		
	} else if ((int) Fov == 20)// x4
	{
		return ((86.25f / 30) * compe) + dist;
		
	} else if ((int) Fov == 13)// x6
	{
	    return ((112.5f / 30) * compe) + dist;
		
    } else { // no open scope and x8
		return ((12.0f / 30) * compe) + dist;
	}
    
}

float GetPitchCustom(float Fov,float compe,float dist,float recScope[9]) {
    if ((int) Fov == 11) //x8
    {
        return ((recScope[8] / 30) * compe);
    } 
	else if ((int) Fov == 13)// x6
	{
	    return ((recScope[7] / 30) * compe) + dist;
    } 
	else if ((int) Fov == 20)// x4
	{
		return ((recScope[6] / 30) * compe) + dist;
	}
	else if ((int) Fov == 26) //x3
	{
		return ((recScope[5] / 30) * compe) + dist;
	} 
	else if ((int) Fov == 44) //x2
	{
        return ((recScope[4] / 30) * compe) + dist;
	} 
	else if ((int) Fov == 55) // redot & hollo
    {
		return ((recScope[3] / 30) * compe) + dist;
	}
	else if ((int) Fov == 70) // no  scope
    {
		return ((recScope[2] / 30) * compe) + dist;
	}
	else if ((int) Fov == 80) // tpp no open scope
    {
		return ((recScope[1] / 30) * compe) + dist;
	}
	else if ((int) Fov == 90) // fpp no open scope
    {
		return ((recScope[0] / 30) * compe) + dist;
	}
}


#endif //XT_ESP_SUPPORT_H

